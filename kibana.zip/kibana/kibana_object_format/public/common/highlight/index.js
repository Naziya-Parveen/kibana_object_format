export { getHighlightHtml } from './highlight_html';
export { getHighlightRequest } from './highlight_request';
